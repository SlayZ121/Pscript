```
└── armstrong_numbers.py

```

**armstrong_numbers.py**

```python
def is_armstrong_number(num):
    """Checks if a number is an Armstrong number.

    Args:
        num: The number to check.

    Returns:
        True if the number is an Armstrong number, False otherwise.
    """
    num_str = str(num)
    num_digits = len(num_str)
    sum_of_powers = sum(int(digit) ** num_digits for digit in num_str)
    return sum_of_powers == num


def find_armstrong_numbers(n):
    """Finds all Armstrong numbers between 1 and n.

    Args:
        n: The upper limit of the range.

    Returns:
        A list of Armstrong numbers.
    """
    armstrong_numbers = []
    for i in range(1, n + 1):
        if is_armstrong_number(i):
            armstrong_numbers.append(i)
    return armstrong_numbers


if __name__ == "__main__":
    upper_limit = int(input("Enter the upper limit: "))
    armstrong_numbers = find_armstrong_numbers(upper_limit)
    print("Armstrong numbers between 1 and", upper_limit, "are:", armstrong_numbers)
```

**Explanation:**

1. **`is_armstrong_number(num)` function:**
   - Takes an integer `num` as input.
   - Calculates the number of digits in the number.
   - Iterates through each digit of the number:
     - Raises the digit to the power of the number of digits.
     - Adds the result to a running sum.
   - Returns `True` if the sum of the powers is equal to the original number, indicating an Armstrong number. Otherwise, returns `False`.

2. **`find_armstrong_numbers(n)` function:**
   - Takes an integer `n` as the upper limit of the range.
   - Initializes an empty list `armstrong_numbers` to store the found Armstrong numbers.
   - Iterates through numbers from 1 to `n`:
     - Calls the `is_armstrong_number` function to check if the current number is an Armstrong number.
     - If it is, appends the number to the `armstrong_numbers` list.
   - Returns the `armstrong_numbers` list.

3. **Main execution block (`if __name__ == "__main__":`)**
   - Prompts the user to enter the upper limit of the range.
   - Calls the `find_armstrong_numbers` function to get the list of Armstrong numbers within the specified range.
   - Prints the result to the console.